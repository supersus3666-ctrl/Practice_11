"""Регрессионные автотесты для order.calculate_total (версия 2)."""
import pytest
from order import calculate_total

ONE = [{"price": 100, "qty": 1}]
TWO = [{"price": 100, "qty": 2}]


# ---------- Позитивные (старая логика) ----------
def test_no_discount():
    """TC-01. Позитивный: расчёт без скидки."""
    assert calculate_total(TWO) == 200.00


def test_discount_50():
    """TC-02. Позитивный: скидка 50%."""
    assert calculate_total(TWO, 50) == 100.00


def test_multiple_items_sum():
    """Позитивный: сумма нескольких товаров, затем скидка."""
    items = [{"price": 10.5, "qty": 2}, {"price": 4, "qty": 3}]  # 21 + 12 = 33
    assert calculate_total(items, 10) == 29.70


# ---------- Негативные ----------
def test_invalid_discount_above_100():
    """TC-03. Негативный: скидка 101%."""
    with pytest.raises(ValueError):
        calculate_total(ONE, 101)


def test_invalid_discount_negative():
    """Негативный: отрицательная скидка."""
    with pytest.raises(ValueError):
        calculate_total(ONE, -1)


def test_qty_zero():
    """TC-04. Негативный: количество 0."""
    with pytest.raises(ValueError):
        calculate_total([{"price": 100, "qty": 0}])


@pytest.mark.parametrize("price", [0, -5])
def test_invalid_price(price):
    """Негативный: цена 0 и отрицательная."""
    with pytest.raises(ValueError):
        calculate_total([{"price": price, "qty": 1}])


# ---------- Граничные ----------
def test_discount_zero_boundary():
    """TC-05. Граничный: скидка 0%."""
    assert calculate_total(TWO, 0) == 200.00


def test_discount_100_boundary():
    """TC-06. Граничный: скидка 100%."""
    assert calculate_total(TWO, 100) == 0.00


def test_min_qty_and_min_price():
    """Граничный: qty=1, price=0.01."""
    assert calculate_total([{"price": 0.01, "qty": 1}]) == 0.01


# ---------- Новая логика (промокод) ----------
def test_promo_sale10():
    """TC-07. Интеграционный: SALE10 + скидка 10% = 20%."""
    assert calculate_total(ONE, 10, "SALE10") == 80.00


def test_promo_without_discount():
    """Позитивный: SALE10 без базовой скидки = 10%."""
    assert calculate_total(ONE, 0, "SALE10") == 90.00


def test_unknown_promo_ignored():
    """Негативный/позитивный: неизвестный промокод игнорируется."""
    assert calculate_total(ONE, 10, "FAKE") == 90.00


def test_promo_to_exactly_100():
    """Граничный: 90% + SALE10 = ровно 100%."""
    assert calculate_total(ONE, 90, "SALE10") == 0.00


def test_promo_caps_discount_at_100():
    """TC-08. Интеграционный: 95% + SALE10 -> итоговая скидка 100%, итог 0.00."""
    assert calculate_total(ONE, 95, "SALE10") == 0.00


def test_promo_with_max_discount_not_negative():
    """Интеграционный: 100% + SALE10 не даёт отрицательной суммы."""
    assert calculate_total(ONE, 100, "SALE10") == 0.00
